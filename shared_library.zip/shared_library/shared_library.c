#include <stdio.h>

int function() {
    printf("calling function\n");
    return 7;
}